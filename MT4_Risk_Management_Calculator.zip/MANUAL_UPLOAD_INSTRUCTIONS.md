# Manual GitHub Upload Instructions

Since we're having issues with Git commands in the terminal, here's how to upload files manually to your GitHub repository:

## Step 1: Create a ZIP file of your project

1. Select all the files and folders in your project directory:
   - mt4_fastapi_backend/
   - mt4_frontend/
   - README.md
   - LICENSE
   - .gitignore
   - setup.py
   - install.bat
   - start.bat
   - test_setup.bat
   - GITHUB_UPLOAD.md
   - PROJECT_SUMMARY.md

2. Right-click and select "Send to" > "Compressed (zipped) folder"
3. Name the ZIP file "MT4_Risk_Management_Calculator.zip"

## Step 2: Upload to GitHub using the web interface

1. Open your web browser and go to: https://github.com/Satviksangamkar/Risk-Management-MT4

2. If the repository is empty, you'll see a "Quick setup" page:
   - Click on "uploading an existing file"

3. If the repository already has files:
   - Click on "Add file" > "Upload files"

4. On the upload page:
   - Drag and drop your ZIP file OR click "choose your files" to select it
   - Add a commit message: "Initial upload of MT4 Risk Management Calculator"
   - Click "Commit changes"

## Step 3: Extract the ZIP file on GitHub (if needed)

If you want to extract the ZIP file directly on GitHub:

1. Install the GitHub CLI: https://cli.github.com/
2. Run these commands:
   ```
   gh auth login
   gh repo clone Satviksangamkar/Risk-Management-MT4
   cd Risk-Management-MT4
   # Extract the ZIP file
   # Add, commit and push the extracted files
   git add .
   git commit -m "Extract files from ZIP"
   git push
   ```

## Alternative: Upload files individually

If you prefer, you can upload files and folders individually:

1. Go to your repository: https://github.com/Satviksangamkar/Risk-Management-MT4
2. Click "Add file" > "Upload files"
3. Upload files and folders one by one
4. Add a commit message for each upload
5. Repeat until all files are uploaded

## Important files to upload:

1. **Documentation files**:
   - README.md
   - mt4_fastapi_backend/README.md
   - mt4_fastapi_backend/API_DOCUMENTATION.md
   - mt4_fastapi_backend/FUNCTION_REFERENCE.md
   - mt4_frontend/README.md
   - GITHUB_UPLOAD.md
   - PROJECT_SUMMARY.md

2. **Backend code**:
   - mt4_fastapi_backend/main.py
   - mt4_fastapi_backend/requirements.txt
   - mt4_fastapi_backend/test_server.py
   - mt4_fastapi_backend/app/ (folder with all contents)

3. **Frontend code**:
   - mt4_frontend/index.html
   - mt4_frontend/styles.css
   - mt4_frontend/script.js

4. **Helper scripts**:
   - install.bat
   - start.bat
   - test_setup.bat

5. **Project files**:
   - LICENSE
   - .gitignore
   - setup.py
